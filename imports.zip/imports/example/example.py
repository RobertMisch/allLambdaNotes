from arithmetic.adder import add

def call_adder(a, b):
    return add(a, b)

