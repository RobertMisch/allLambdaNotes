from example.example import call_adder

print(call_adder(1, 3))


